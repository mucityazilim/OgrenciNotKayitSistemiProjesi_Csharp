﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OgrenciNotKayitSistemiProjesi
{
    public partial class FrmNotIslemleri : Form
    {
        public FrmNotIslemleri()
        {
            InitializeComponent();
        }
        DbFakulteEntities db = new DbFakulteEntities();
        public void listele()
        {

           

            var ogrenci = from x in db.TblOgrenci
                          select new
                          {
                              x.ogrenciID,
                              AdSoyad = x.ogrenciID + " - " + x.ad + " " + x.soyad,
                              x.durum
                          };
            cbOgrenci.DisplayMember = "AdSoyad";
            cbOgrenci.ValueMember = "ogrenciID";
            cbOgrenci.DataSource = ogrenci.Where(x => x.durum == true).ToList();

            cbDers.DisplayMember = "dersAdi";
            cbDers.ValueMember = "dersID";
            cbDers.DataSource = db.TblDersler.Where(x => x.durum == true).ToList();

            cbDersAra.DisplayMember = "dersAdi";
            cbDersAra.ValueMember = "dersID";
            cbDersAra.DataSource = db.TblDersler.Where(x => x.durum == true).ToList();

            dataGridView1.DataSource = db.notListesi().ToList();
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                if (int.Parse(dataGridView1.Rows[i].Cells["ortalama"].Value.ToString()) < 50)
                    dataGridView1.Rows[i].Cells["sonuc"].Style.ForeColor = Color.Red;
                else
                    dataGridView1.Rows[i].Cells["sonuc"].Style.ForeColor = Color.Green;
            }
            txtID.Text = "";
            txtVize.Value = 0;
            txtFinal.Value = 0;
            txtOrtalama.Text = "";
            txtSonuc.Text = "";

        }
        private void FrmNotIslemleri_Load(object sender, EventArgs e)
        {

            listele();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int vize, final, ortalama;
            vize = int.Parse(txtVize.Text);
            final = int.Parse(txtFinal.Text);
            ortalama = vize * 40 / 100 + final * 60 / 100;
            txtOrtalama.Text = ortalama.ToString();

            if (ortalama < 50)

                txtSonuc.Text = "Kaldı";
            else
                txtSonuc.Text = "Geçti";

        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (txtOrtalama.Text == "")
                MessageBox.Show("Lütfen önce ortalama hesaplamasını yapınız ", "Hata");
            else
            {
                var x = new TblNotlar();
                x.ogrenci = int.Parse(cbOgrenci.SelectedValue.ToString());
                x.ders = int.Parse(cbDers.SelectedValue.ToString());
                x.vize = int.Parse(txtVize.Value.ToString());
                x.final = int.Parse(txtFinal.Value.ToString());
                x.ortalama = int.Parse(txtOrtalama.Text);
                x.sonuc = txtSonuc.Text;
                x.durum = true;
                db.TblNotlar.Add(x);
                db.SaveChanges();
                MessageBox.Show("Not kaydı tamam ");
            }
            listele();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();


        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
                MessageBox.Show("Silmek istediğiniz kaydı seçiniz ", "hata");
            else
            {
                int id = int.Parse(txtID.Text);
                var x = db.TblNotlar.Find(id);
                x.durum = false;
                db.SaveChanges();
                MessageBox.Show("Kayıt silindi ");
            }

            listele();

        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
                MessageBox.Show("Güncellemek istediğiniz kaydı seçiniz ve tüm alanları giriniz ", "hata");
            else
            {
                int id = int.Parse(txtID.Text);
                var x = db.TblNotlar.Find(id);
                x.ogrenci = int.Parse(cbOgrenci.SelectedValue.ToString());
                x.ders = int.Parse(cbDers.SelectedValue.ToString());
                x.vize = int.Parse(txtVize.Value.ToString());
                x.final = int.Parse(txtFinal.Value.ToString());
                if (txtOrtalama.Text == "")
                    MessageBox.Show("Not hesaplama işlemini yapınız !", "Hata");
                else
                {
                    x.ortalama = int.Parse(txtOrtalama.Text);
                    x.sonuc = txtSonuc.Text;
                    x.durum = true;

                    db.SaveChanges();
                    MessageBox.Show("Kayıt güncellendi ");

                }

            }
            listele();
        }

        private void cbDersAra_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = int.Parse( cbDersAra.SelectedValue.ToString() ) ; 

            dataGridView1.DataSource = db.notListesi3(id).ToList();
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                if (int.Parse(dataGridView1.Rows[i].Cells["ortalama"].Value.ToString()) < 50)
                    dataGridView1.Rows[i].Cells["sonuc"].Style.ForeColor = Color.Red;
                else
                    dataGridView1.Rows[i].Cells["sonuc"].Style.ForeColor = Color.Green;
            } 
        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            listele(); 
        }
    }
}
