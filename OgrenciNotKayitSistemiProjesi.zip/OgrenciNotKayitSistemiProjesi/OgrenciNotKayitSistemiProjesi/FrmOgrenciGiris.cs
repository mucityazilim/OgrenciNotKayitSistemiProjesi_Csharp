﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OgrenciNotKayitSistemiProjesi; 

namespace OgrenciNotKayitSistemiProjesi
{
    public partial class FrmOgrenciGiris : Form
    {
        public FrmOgrenciGiris()
        {
            InitializeComponent();
        }
        DbFakulteEntities db = new DbFakulteEntities();

        public static int ogrNo; 

        private void button1_Click(object sender, EventArgs e)
        {
            ogrNo = int.Parse(txtNumara.Text) ;
            string sifre = txtSifre.Text;
            var ogr = db.TblOgrenci.Find(ogrNo ); 

            if (ogr == null   )
                MessageBox.Show("Numara hatalı ");
            else if ( ogr.ogrenciID != ogrNo || ogr.sifre!= sifre )
                MessageBox.Show("Numara/sifre hatalı ", "Hata");
            else 
            {
                sifre = ""; 
                FrmOgrenciIslemleri2 fr = new FrmOgrenciIslemleri2();
                fr.Show();
                
            }

            txtNumara.Text = "";
            txtSifre.Text = ""; 


        }
    }
}
