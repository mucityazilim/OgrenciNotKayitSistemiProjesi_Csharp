﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OgrenciNotKayitSistemiProjesi
{
    public partial class FrmDersIslemleri : Form
    {
        public FrmDersIslemleri()
        {
            InitializeComponent();
        }
        DbFakulteEntities db = new DbFakulteEntities();
        public void listele()
        {
            var dersler = from x in db.TblDersler
                          select new
                          {
                              x.dersID,
                              x.dersAdi,
                              x.durum
                          };
            dataGridView1.DataSource = dersler.Where(x => x.durum == true).ToList();
            dataGridView1.Columns[2].Visible = false;
            txtID.Text = "";
            txtAd.Text = ""; 

        }
        private void FrmDersIslemleri_Load(object sender, EventArgs e)
        {
            listele();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtAd.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString(); 
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (txtAd.Text == "")
                MessageBox.Show("Lütfen ders adını giriniz ", "Hata");
            else
            {
                var x = new TblDersler();
                x.dersAdi = txtAd.Text;
                x.durum = true;
                db.TblDersler.Add(x);
                db.SaveChanges();
                MessageBox.Show("Ders kaydı tamam ");
            }
            listele();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
                MessageBox.Show("Silmek istediğiniz kaydı seçiniz ", "hata");
            else
            {
                int id = int.Parse(txtID.Text);
                var x = db.TblDersler.Find(id);
                x.durum = false;
                db.SaveChanges();
                MessageBox.Show("Kayıt silindi ");
            }

            listele();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
                MessageBox.Show("Güncellemek istediğiniz kaydı seçiniz ", "hata");
            else
            {
                int id = int.Parse(txtID.Text);
                var x = db.TblDersler.Find(id);
                x.dersAdi = txtAd.Text;

                db.SaveChanges();
                MessageBox.Show("Kayıt güncellendi ");
            }

            listele();
        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            listele(); 
        }
    }
}
