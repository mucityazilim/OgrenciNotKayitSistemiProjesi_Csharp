﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OgrenciNotKayitSistemiProjesi
{
    public partial class FrmOgrenciIslemleri2 : Form
    {
        public FrmOgrenciIslemleri2()
        {
            InitializeComponent();
        }

        DbFakulteEntities db = new DbFakulteEntities();
        int ogrNo=0; 
        private void FrmOgrenciIslemleri2_Load(object sender, EventArgs e)
        {
            ogrNo = FrmOgrenciGiris.ogrNo;
            var ogrenci = db.TblOgrenci.Find(ogrNo);
            var bolum = db.TblBolumler.Find(ogrenci.bolum); 
            txtID.Text = ogrenci.ogrenciID.ToString();
            txtAd.Text = ogrenci.ad.ToString();
            txtSoyad.Text = ogrenci.soyad.ToString();
            txtAdres.Text = ogrenci.adres.ToString();
            txtMail.Text = ogrenci.mail.ToString();
            txtTel.Text = ogrenci.tel.ToString();
            txtResim.Text = ogrenci.resim.ToString();
            txtBolum.Text = bolum.BolumAdi.ToString(); 
            txtSifre.Text = ogrenci.sifre.ToString();
            pictureBox1.ImageLocation = txtResim.Text;
            txtResim.Visible = false;

            dataGridView1.DataSource = db.notListesi4(ogrNo).ToList();

            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                if (int.Parse(dataGridView1.Rows[i].Cells["ortalama"].Value.ToString()) < 50)
                    dataGridView1.Rows[i].Cells["sonuc"].Style.ForeColor = Color.Red;
                else
                    dataGridView1.Rows[i].Cells["sonuc"].Style.ForeColor = Color.Green;
            }


        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if ( txtSifre.Text == "" || txtSifre.Text.Length <5)
                MessageBox.Show("Lütfen şifreniz en az 5 karakter uzunluğunda olsun", "Hata");

            else
            {
                var x = db.TblOgrenci.Find(ogrNo);
                x.sifre = txtSifre.Text;
                db.SaveChanges();
                MessageBox.Show("Şifreniz değiştirildi ");
            }
            txtSifre.Text = ""; 


        }
    }
}
