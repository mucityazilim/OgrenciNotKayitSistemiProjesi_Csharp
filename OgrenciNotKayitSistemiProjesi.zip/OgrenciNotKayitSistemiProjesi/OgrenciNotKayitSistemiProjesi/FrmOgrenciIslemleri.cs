﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OgrenciNotKayitSistemiProjesi
{
    public partial class FrmOgrenciIslemleri : Form
    {
        public FrmOgrenciIslemleri()
        {
            InitializeComponent();
        }
        DbFakulteEntities db = new DbFakulteEntities(); 
        public void listele()
        {
            var ogrenciler = from x in db.TblOgrenci
                             select new
                             {
                                 x.ogrenciID,
                                 x.ad,
                                 x.soyad,
                                 x.adres,
                                 x.mail,
                                 x.tel,
                                 x.resim,
                                 x.bolum,
                                 x.sifre,
                                 x.durum
                             };
            dataGridView1.DataSource = ogrenciler.Where(x=>x.durum==true).ToList();
            dataGridView1.Columns[8].Visible = false;
            dataGridView1.Columns[9].Visible = false;


            txtID.Text = "";
            txtAd.Text = "";
            txtSoyad.Text = "";
            txtAdres.Text = "";
            txtTel.Text = "";
            txtMail.Text = "";
            txtResim.Text = "";
            txtSifre.Text = "";
            cbBolum.DisplayMember = "bolumAdi";
            cbBolum.ValueMember = "bolumID"; 
            cbBolum.DataSource = db.TblBolumler.ToList(); 

        }
        private void FrmOgrenciIslemleri_Load(object sender, EventArgs e)
        {
            listele(); 

        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (txtAd.Text == "" || txtSoyad.Text == "" || txtAdres.Text == "" || txtMail.Text == "" || txtTel.Text == "" || txtSifre.Text == "" )
                MessageBox.Show("Lütfen tüm alanları eksiksiz giriniz ", "Hata");
            else
            {
                var x = new TblOgrenci();
                x.ad = txtAd.Text;
                x.soyad = txtSoyad.Text;
                x.adres = txtAdres.Text;
                x.mail = txtMail.Text;
                x.tel = txtTel.Text;
                x.resim = txtResim.Text;
                x.bolum = int.Parse( cbBolum.SelectedValue.ToString() ) ;
                x.sifre = txtSifre.Text;

                x.durum = true;
                
                db.TblOgrenci.Add(x);
                db.SaveChanges();
                MessageBox.Show("Ogrenci kaydı tamam ");
            }
            listele();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
                MessageBox.Show("Silmek istediğiniz kaydı seçiniz ", "hata");
            else
            {
                int id = int.Parse(txtID.Text);
                var x = db.TblOgrenci.Find(id);
                x.durum = false;
                db.SaveChanges();
                MessageBox.Show("Kayıt silindi ");
            }

            listele();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtAd.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtSoyad.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtAdres.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtMail.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtTel.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtResim.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            cbBolum.SelectedValue= int.Parse( dataGridView1.CurrentRow.Cells[7].Value.ToString() ) ;
            txtSifre.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            pictureBox1.ImageLocation = txtResim.Text; 


        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (txtAd.Text == "" || txtSoyad.Text == "" || txtAdres.Text == "" || txtMail.Text == "" || txtTel.Text == "" || txtSifre.Text == "")
                MessageBox.Show("Lütfen güncellemek istediğiniz kaydı seçiniz ve tüm alanları eksiksiz giriniz ", "Hata");

            else
            {
                int id = int.Parse(txtID.Text);
                var x = db.TblOgrenci.Find(id);
                x.ad = txtAd.Text;
                x.soyad = txtSoyad.Text;
                x.adres = txtAdres.Text;
                x.mail = txtMail.Text;
                x.tel = txtTel.Text;
                x.resim = txtResim.Text;
                x.bolum = int.Parse(cbBolum.SelectedValue.ToString());
                x.sifre = txtSifre.Text;
                x.durum = true;                
                db.SaveChanges();
                MessageBox.Show("Kayıt güncellendi ");
            }
            listele(); 

        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            txtResim.Text = openFileDialog1.FileName;
            pictureBox1.ImageLocation = txtResim.Text; 
        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            listele(); 
        }
    }
}
