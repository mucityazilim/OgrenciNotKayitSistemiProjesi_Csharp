﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OgrenciNotKayitSistemiProjesi
{
    public partial class FrmAkademisyenGiris : Form
    {
        public FrmAkademisyenGiris()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtKullanici.Text =="" || txtSifre.Text=="")
                MessageBox.Show("Lütfen tüm alanları eksiksiz giriniz ", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                if (txtKullanici.Text=="admin" && txtSifre.Text=="123")
                {
                    FrmAkademisyenIslemleri fr = new FrmAkademisyenIslemleri();
                    fr.Show(); 
                }
                else
                    MessageBox.Show("Hatalı Kullanıcı Adı/Parola", "Hata");
            }
            txtKullanici.Text = "";
            txtSifre.Text = ""; 


        }
    }
}
