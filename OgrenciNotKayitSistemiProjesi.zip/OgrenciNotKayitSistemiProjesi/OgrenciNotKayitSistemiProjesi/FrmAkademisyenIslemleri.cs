﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OgrenciNotKayitSistemiProjesi
{
    public partial class FrmAkademisyenIslemleri : Form
    {
        public FrmAkademisyenIslemleri()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmBolumIslemleri fr = new FrmBolumIslemleri();
            fr.Show(); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmDersIslemleri fr = new FrmDersIslemleri();
            fr.Show(); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmOgrenciIslemleri fr = new FrmOgrenciIslemleri();
            fr.Show(); 
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmNotIslemleri fr = new FrmNotIslemleri();
            fr.Show(); 
        }
    }
}
