﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace OgrenciNotKayitSistemiProjesi
{
    public partial class FrmBolumIslemleri : Form
    {
        public FrmBolumIslemleri()
        {
            InitializeComponent();
        }
        DbFakulteEntities db = new DbFakulteEntities();
        public void listele()
        {
            var bolumler = from x in db.TblBolumler
                           select new
                           {
                               x.BolumID,
                               x.BolumAdi,
                               x.durum
                           };

            dataGridView1.DataSource = bolumler.Where(x => x.durum == true).ToList();
            dataGridView1.Columns[2].Visible = false;
            txtID.Text = "";
            txtAd.Text = "";

        }
        private void FrmBolumIslemleri_Load(object sender, EventArgs e)
        {
            listele();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtAd.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();

        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (txtAd.Text == "")
                MessageBox.Show("Lütfen bölüm adını giriniz ", "Hata");
            else
            {
                var x = new TblBolumler();
                x.BolumAdi = txtAd.Text;
                x.durum = true;
                db.TblBolumler.Add(x);
                db.SaveChanges();
                MessageBox.Show("Bölüm kaydı tamam ");
            }
            listele();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
                MessageBox.Show("Silmek istediğiniz kaydı seçiniz ", "hata");
            else
            {
                int id = int.Parse(txtID.Text);
                var x = db.TblBolumler.Find(id);
                x.durum = false;
                db.SaveChanges();
                MessageBox.Show("Kayıt silindi ");
            }

            listele();


        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
                MessageBox.Show("Güncellemek istediğiniz kaydı seçiniz ", "hata");
            else
            {
                int id = int.Parse(txtID.Text);
                var x = db.TblBolumler.Find(id);
                x.BolumAdi = txtAd.Text; 

                db.SaveChanges();
                MessageBox.Show("Kayıt güncellendi ");
            }

            listele();

        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            listele(); 
        }
    }
}
